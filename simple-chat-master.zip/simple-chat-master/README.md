# simple-chat
A simple chat application in nodejs and mongodb

Read
https://medium.com/@amkurian/simple-chat-application-in-node-js-using-express-mongoose-and-socket-io-ee62d94f5804
